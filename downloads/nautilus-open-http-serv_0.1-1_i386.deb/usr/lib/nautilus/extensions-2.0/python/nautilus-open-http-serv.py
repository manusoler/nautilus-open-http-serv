#!/usr/bin/env python
#Este archivo esta en encoding: utf-8

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

# Written by Manuel Soler Moreno <manusoler@gmail.com>

'''
Módulo con todas las clases de la interfaz de la aplicación.
'''

import pygtk
import gtk
import gtk.glade
import nautilus
import os
import os.path
import subprocess
import thread
import time

pygtk.require("2.0")

PROY_PATH = "/usr/share/nautilus-open-http-serv"
GLADE_PATH = os.path.join(PROY_PATH, "glade")
PIX_PATH = os.path.join(PROY_PATH, "pixmaps")



class wPrincipal:
	'''
	Ventana principal de la aplicación.
	Esta debe ser la que se cree en primera instancia.
	Desde ella se crearan los demás objetos.
	'''

	def __init__(self, file):
		'''Constructor de la clase'''
		# Construimos a partir del archivo glade la ventana wPrincipal
		self.glade = gtk.glade.XML(os.path.join(GLADE_PATH, "nautilus-open-http-serv.glade"), root="wPrincipal")
		# Conectamos todas las señales especificadas en el archivo
		self.glade.signal_autoconnect(self)
		# Establecemos un icono
		self.glade.get_widget("wPrincipal").set_icon(gtk.gdk.pixbuf_new_from_file(os.path.join(PIX_PATH, "web.png")))

		# Establecemos todas las imagenes
		self.glade.get_widget("image").set_from_file(os.path.join(PIX_PATH, "bigweb.png"))

		self.glade.get_widget("lblLocation").set_markup("<b>%s</b>" % file.get_uri()[7:])
		self.buf = gtk.TextBuffer()
		self.buf.set_text("SimpleHTTPServer running...")
		self.glade.get_widget("txtMessages").set_buffer(self.buf)

		# self.stop = False
		# Ejecutamos el servidor
		self.popen = subprocess.Popen(["python", "-m", "SimpleHTTPServer"], stdout=subprocess.PIPE, cwd=file.get_uri()[7:])
		# TODO thread.start_new_thread(self.get_info, ())

	def on_wPrincipal_delete_event(self, widget, event):
		'''
		Evento al cerrar la ventana.
		Abortamos la ejecución del SimpleHTTPServ y salimos
		'''
		self.stop = True
		os.kill(self.popen.pid, 9)
		gtk.main_quit()

	def on_btnStop_clicked(self, widget):
		'''Evento al pulsar sobre para.
			Abortamos la ejecución del SimpleHTTPServ y salimos'''
		self.stop = True
		os.kill(self.popen.pid, 9)
		gtk.main_quit()
	
	def get_info(self):
		# TODO
		while not self.stop:
			arch =  self.popen.stdout
			#arch = open(self.popen.stdout, "r")
			self.buf.set_text(arch.readlines()[0])
			self.glade.get_widget("txtMessages").set_buffer(self.buf)
			time.sleep(1)

class OpenHTTPServExtension(nautilus.MenuProvider):
    def __init__(self):
        self.file_names = []

    def menu_activate_cb(self, menu, file):
        """Called when the user selects the menu Open Simple HTTP Server."""
        gtk.gdk.threads_init()
        wp = wPrincipal(file)
        gtk.main()

    def get_background_items(self, window, file):
        """Called when the user selects a file in Nautilus."""
        # Put an item in nautilus menu
        item = nautilus.MenuItem("NautilusPython::open_http_serv",
                                 "Open Simple HTTP Server" ,
                                 "Open Simple HTTP Server",
                                 "open-http-serv")
        item.connect("activate", self.menu_activate_cb, file)
        return item,
		

if __name__=="__main__":
	try:
		# Creamos una instancia de la ventana principal
		app = wPrincipal()
		# Inidicamos a gtk que use las macros de Python para permitir
		# multiples hilos
		gtk.gdk.threads_init()
		# Y la arrancamos
		gtk.main()
	except KeyboardInterrupt:
		pass
